import UIKit


//MARK: Создай кортеж для двух человек с одинаковыми типами данных и параметрами. При том одни значения доставай по индексу, а другие — по параметру. Пример (для демонстрации задачи, чтобы было понимание, что надо делать):

let studentFirst = (name: "Harry", surName: "Potter", age: 23, faculty: "Gryffindor")
let studentTwo = (name: "Draco", surName: "Malfoy", age: 22, faculty: "Slytherin")

//MARK: Вызов значения по индексу
studentFirst.0
studentFirst.1
studentFirst.2
studentFirst.3

//MARK: Вызов значения по параметру
studentTwo.name
studentTwo.surName
studentTwo.age
studentTwo.faculty

//MARK: Создай массив «дни в месяцах» (12 элементов содержащих количество дней в соответствующем месяце). Используя цикл for и этот массив:

let nameMonths = ["January", "February", "March", "April","May","June","July","August","September","October","November","December"]
let daysMonths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

//MARK: выведи количество дней в каждом месяце

for c in 0 ..< nameMonths.count {
    //print("\(nameMonths[c]): \(daysMonths[c]) days")
}

//MARK: используй еще один массив с именами месяцев чтобы вывести название месяца + количество дней

let nameMonthsAndDays: [ (String, Int) ] = [ ("January", 31), ("February", 28), ("March", 31), ("April",31), ("May",31), ("June",31), ("July",31), ("August",31), ("September", 30), ("October", 31), ("November", 30), ("December", 31) ]

for c in 0 ..< nameMonthsAndDays.count {
    //print("Months: \(nameMonthsAndDays[c].0), Days: \(nameMonthsAndDays[c].1) ")
}

//MARK: сделай тоже самое, но используя массив кортежей с параметрами (имя месяца, количество дней)

let nameMonthsAndDaysParametr = [(months: "January",days: 31), (months: "February",days: 28),(months: "March",days: 31),(months: "April",days: 31),(months: "May",days: 31),(months: "June",days: 31),(months: "July",days: 31),(months: "August",days: 31),(months: "September",days: 30),(months: "October",days: 31),(months: "November",days: 30),(months: "December",days: 31)]

for c in 0 ..< nameMonthsAndDaysParametr.count {
    //print("\(nameMonthsAndDaysParametr[c].months) \(nameMonthsAndDaysParametr[c].days)")
}

//MARK: сделай тоже самое, только выведи дни в обратном порядке (порядок в исходном массиве не меняется)

for c in (0 ..< nameMonthsAndDaysParametr.count).reversed() {
    print("\(nameMonthsAndDaysParametr[c].months) \(nameMonthsAndDaysParametr[c].days)")
}

//MARK: для произвольно выбранной даты (месяц и день) посчитай количество дней до конца года

var dataMoths = (3, 22)
var sumDayes = 0

for c in 0 ..< dataMoths.0 - 1 {
    sumDayes += daysMonths[c]
}
print(sumDayes + dataMoths.1)

//MARK: Создай словарь, как журнал студентов, где имя и фамилия студента это ключ, а оценка за экзамен — значение.

var magazine: [String: Int] = ["Harry Potter": 4, "Ronald Weasley": 3, "Hermione Granger": 5, "Neville Longbottom": 3, "Draco Malfoy": 5,]

//MARK: Повысь студенту оценку за экзамен
magazine["Ronald Weasley"] = 4

//MARK: Если оценка положительная (4 или 5) или удовлетворительная (3), то выведи сообщение с поздравлением, отрицательная (1, 2) - отправь на пересдачу

for magazineValues in magazine.values {
    if magazineValues == 4 {
        print("Поздравляю, ваша оцнка \(magazineValues)")
        if magazineValues == 3 {
            print("Поздравляю, ваша оценка \(magazineValues)")
            if magazineValues == 5 {
                print("Поздравляю, ваша оценка \(magazineValues)")
                if magazineValues == 2 {
                    print("Ваша оценка \(magazineValues), идите на пересдачу!")
                }
            }
        }
    }
}

//MARK: Добавь еще несколько студентов — это будут новые одногруппники!
magazine["Cedric Diggory"] = 4
magazine["Luna Lovegood"] = 5

//MARK: Удали одного студента — он отчислен
magazine.removeValue(forKey: "Draco Malfoy")

//MARK: Посчитай средний балл всей группы по итогам экзамена

var averageMark = 0
for magazineVal in magazine.values {
    averageMark += magazineVal
}
print("Средний балл группы \(averageMark/magazine.values.count)")
